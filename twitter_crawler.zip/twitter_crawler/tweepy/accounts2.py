consumer_key = '3s8mKNug2xKXBUbqxUNPrGuNZ'
consumer_secret = '5sgBunJuGP2SYWLINWj92uSCZX50FU5g5Okrj3fZD5yBz9IOS1'
access_token = '232838593-WCMaCa4CaqeCGwYUaWx4YC4bK2UagXNyT3KXJXEV'
access_token_secret = 'XpbSRCQucdXl4DYA2KqC23MJ2fkaZRGbaYzn2vsqdEI1l'


