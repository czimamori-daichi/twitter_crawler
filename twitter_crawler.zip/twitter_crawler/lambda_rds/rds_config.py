db_username = "crawler"
db_password = "twittercrawler"
db_name = "followers"
